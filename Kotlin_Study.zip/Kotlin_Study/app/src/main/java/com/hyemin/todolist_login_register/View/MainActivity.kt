package com.hyemin.todolist_login_register.View

import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.hyemin.todolist_login_register.Model.App
import com.hyemin.todolist_login_register.Model.MemoAdapter
import com.hyemin.todolist_login_register.R
import com.hyemin.todolist_login_register.Room.Memo
import com.hyemin.todolist_login_register.Room.MemoDao
import com.hyemin.todolist_login_register.Room.MemoDatabase
import kotlinx.android.synthetic.main.activity_memolist.*
import java.lang.Exception

class MainActivity : AppCompatActivity() {

    private var memoList = listOf<Memo>()
    private var memoDb: MemoDatabase? = null
    lateinit var Madapter: MemoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_memolist)

        memoDb = MemoDatabase.getInstance(this)
        Madapter = MemoAdapter(this, memoList)

        val logout = findViewById<TextView>(R.id.logout)

        logout.setOnClickListener{
            val intent = Intent(applicationContext, LoginActivity::class.java)
            applicationContext.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
            App.prefs.checkBox = false
            App.prefs.email = ""
            App.prefs.passwd = ""
        }

        val r = Runnable {
            try{
                memoList = memoDb?.memoDao()?.getAll()!!
                Madapter = MemoAdapter(this, memoList)
                Madapter.notifyDataSetChanged()

                RecyclerView.adapter = Madapter
                RecyclerView.layoutManager = LinearLayoutManager(this)
                RecyclerView.setHasFixedSize(true)

            }catch(e: Exception){
                Log.d("tag", "Error = $e")
            }

        }

        val thread = Thread(r)
        thread.start()

        AddBtn.setOnClickListener{
            val i = Intent(this, AddActivity::class.java)
            applicationContext.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP))
                finish()
        }

        val fab: View = findViewById(R.id.add_todo)
        fab.setOnClickListener { view ->
            Snackbar.make(view, "Here's a Snackbar", Snackbar.LENGTH_LONG)
                .setAction("Action", null)
                .show()
        }
    }
}
