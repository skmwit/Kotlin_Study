package com.hyemin.todolist_login_register.Model

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.hyemin.todolist_login_register.R
import com.hyemin.todolist_login_register.Room.Memo

class MemoAdapter(val context: Context, val memo: List<Memo>) :
RecyclerView.Adapter<MemoAdapter.Holder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view=LayoutInflater.from(context).inflate(R.layout.item_memo, parent, false)
        return Holder(view)
    }

    override fun getItemCount(): Int {
        return memo.size
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder?.bind(memo[position])
    }

    inner class Holder(itemView: View?):RecyclerView.ViewHolder(itemView!!) {
        val title = itemView?.findViewById<TextView>(R.id.itemName)
        val due = itemView?.findViewById<TextView>(R.id.itemDue)
        //val time = itemView?.findViewById<TextView>(R.id.itemTime)

        fun bind(memo:Memo){
            title?.text = memo.title
            due?.text = "마감 : " + memo.month.toString() + "월 " + memo.day.toString() + "일 " + memo.hour.toString()+ "시 "+memo.minute.toString() + "분"
        }
    }
}