package com.hyemin.todolist_login_register.View

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.hyemin.todolist_login_register.R
import com.hyemin.todolist_login_register.Room.Memo
import com.hyemin.todolist_login_register.Room.MemoDatabase
import kotlinx.android.synthetic.main.activity_add.*

class AddActivity: AppCompatActivity() {

    private var memoDb: MemoDatabase? = null

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        memoDb = MemoDatabase.getInstance(this)

        val addRunnable = Runnable{
            val newMemo = Memo()
            newMemo.title = add_title.text.toString()
            newMemo.content = add_content.text.toString()
            newMemo.year = 2019
            newMemo.month = 10
            newMemo.day = 24
            newMemo.hour = 13
            newMemo.minute = 49
            memoDb?.memoDao()?.insert(newMemo)
        }

        add_button.setOnClickListener{
            val addThread = Thread(addRunnable)
            addThread.start()

            val i = Intent(this, MainActivity::class.java)
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP))
            finish()

        }
    }

    override fun onDestroy() {
        memoDb?.destroyInstance()
        super.onDestroy()
    }
}